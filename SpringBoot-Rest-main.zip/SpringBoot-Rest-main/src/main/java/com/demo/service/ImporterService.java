package com.demo.service;

import org.springframework.stereotype.Service;

@Service
public class ImporterService {
    public String loadData(){
        return "success";
    }
}
